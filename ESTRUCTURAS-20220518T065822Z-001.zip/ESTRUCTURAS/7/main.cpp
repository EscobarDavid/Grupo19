/*
	Universidad de las Fuerzas Armadas "ESPE"
	Ejercicio # (completar)
	Arias Xavier, Escobar David, Ramírez Erick, Yánez Michelle
	Fecha de creación: 16/05/2022
	Fecha de modificación: 17/05/2022
	Grupo 5 y 9
	https://github.com/EscobarDavid/Grupo5_4698_EstructuraDeDatos
	https://github.com/ErickRamirezO/Trabajos-Grupo-9
*/

#include <iostream>
using namespace std;

int main(void)
 { A Objeto;

   Objeto.defineA(3);
   cout << P(Objeto) << endl;
   return 0;
 }
