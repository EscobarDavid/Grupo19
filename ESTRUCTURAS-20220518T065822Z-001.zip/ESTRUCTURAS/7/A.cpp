#include "A.h"
 void A::defineA(int x)
  { a = x; }

 int A::dameA(void)
  { return a; }
