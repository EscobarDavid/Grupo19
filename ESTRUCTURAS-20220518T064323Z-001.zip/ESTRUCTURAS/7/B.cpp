#include "B.h"

 void B::defineB(int x)
  { b = x; }

 int B::dameB(void)
  { return b; }

